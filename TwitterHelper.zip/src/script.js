console.log("Twitter Share Fix carregado!");

document.addEventListener("click", async (event) => {
    // Verifica se o botão "Copy Link" foi clicado
    const button = event.target.closest('[data-testid="copyLink"]');
    if (!button) return;

    event.preventDefault();

    // Obtém o link do tweet diretamente do botão
    const tweetElement = button.closest("article");
    if (!tweetElement) {
        alert("Erro: Não foi possível encontrar o tweet.");
        return;
    }

    // Tenta obter o link a partir dos metadados
    let tweetURL = document.location.href;
    if (!tweetURL.includes("status")) {
        alert("Erro: Não parece ser um link de tweet válido.");
        return;
    }

    // Converte o link para fxtwitter.com
    const fixedURL = convertToFxTwitter(tweetURL);

    try {
        await navigator.clipboard.writeText(fixedURL);
        alert("✅ Link otimizado copiado: " + fixedURL);
    } catch (err) {
        console.error("Erro ao copiar o link:", err);
        alert("❌ Erro ao copiar o link.");
    }
});

// Converte o link para o formato fxtwitter.com
function convertToFxTwitter(url) {
    return url.replace(/(x|twitter)\.com/, "fxtwitter.com");
}
